"use client"

import nextConfig from "../next.config"

export default function SyntheticV0PageForDeployment() {
  return <nextConfig />
}