# bootstrap.ps1 – Quantum Pi Forge Ignition Script
# Run from your project root (not System32)

Write-Host "🚀 Quantum Pi Forge Bootstrap Starting..."

# Ensure Node.js is installed
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Error "Node.js not found. Please install Node.js LTS from https://nodejs.org/"
    exit 1
}

# Ensure npm is available
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    Write-Error "npm not found. Please reinstall Node.js."
    exit 1
}

# Install pnpm globally if missing
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
    Write-Host "📦 Installing pnpm globally..."
    npm install -g pnpm
}

# Install dependencies
Write-Host "📦 Installing project dependencies..."
pnpm install

# Build and export static bundle
Write-Host "⚙️ Building and exporting..."
pnpm build
pnpm export

# Verify /out exists
if (-not (Test-Path .\out)) {
    Write-Error "❌ Export failed: /out directory not found."
    exit 1
}

# Compress /out into root-flattened ZIP
Write-Host "📦 Creating quantum-pi-forge-v2.zip..."
Compress-Archive -Path .\out\* -DestinationPath .\quantum-pi-forge-v2.zip -Force

Write-Host "✅ Bootstrap complete. Artifact sealed at quantum-pi-forge-v2.zip"
