"use client"

import  from "../src/index"

export default function SyntheticV0PageForDeployment() {
  return < />
}